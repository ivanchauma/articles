import { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Provider } from 'react-redux';
import { store } from './store';
//import './App.css';
//
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Home from './components/Home';
import NavbarComponent from './components/NavbarComponent';
import FooterComponent from './components/FooterComponent';
import Articles from './components/Articles';

import { Container, Row, Col } from 'react-bootstrap';

import { Routes, Route } from 'react-router';


import { BrowserRouter } from 'react-router';

import { checkAuth } from './features/auth/authSlice';
import Preferences from './components/Preferences';

const App: React.FC = () => {
  // Dispatch checkAuth on initial load to check if user is authenticated
  useEffect(() => {
    store.dispatch(checkAuth());
  }, []);

  return (
    <Provider store={store}>
      <BrowserRouter>
      <Container className="px-3"> {/* Adding px-3 to give some padding to the container */}
         <NavbarComponent />
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/articles" element={<Articles />} />
        <Route path="/preferences" element={<Preferences />} />
      </Routes>
      </Container>
      <FooterComponent className="mt-4" />
      </BrowserRouter>
    </Provider>
  )
}

export default App