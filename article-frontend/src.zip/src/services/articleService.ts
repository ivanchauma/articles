import axios from 'axios';
import API_URL from '../Util/Servers';

//const API_URL = 'http://localhost:8000/api';

export const fetchArticlesService = async (page: number, token: string, titleFilter: string, sourceFilter: string, dateFilter: string) => {
    try {
        const response = await axios.get(`${API_URL}/articles?page=${page}&title=${titleFilter}&source=${sourceFilter}&date=${dateFilter}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        return response;
      } catch (error: any) {
        throw new Error(error.response?.data?.message || 'Error fetching articles');
      }
};

export const fetchUserArticlesService = async (page: number, token: string) => {
  //const response = await axios.get(`${API_URL}/userarticles?page=${page}`);
  try {
    const response = await axios.get(`${API_URL}/userarticles?page=${page}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response;
  } catch (error: any) {
    throw new Error(error.response?.data?.message || 'Error fetching user articles');
  }
};
