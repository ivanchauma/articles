<?php

namespace App;

interface NewsServiceInterface
{
    //
    public function getArticles($query);
}
