import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { fetchArticlesService, fetchUserArticlesService } from '../../services/articleService';

interface ArticleState {
  articles: any[]; // You can replace 'any' with a more specific type for articles
  userArticles: any[]; // Articles specific to the logged-in user
  error: string | null;
  currentPage: number;
  totalPages: number;
}

const initialState: ArticleState = {
  articles: [],
  userArticles: [],
  error: null,
  currentPage: 1,
  totalPages: 1,
};

// Define the slice
const articleSlice = createSlice({
  name: 'articles',
  initialState,
  reducers: {
    setArticles(state, action: PayloadAction<{ articles: any[]; totalPages: number }>) {
      state.articles = action.payload.articles;
      state.totalPages = action.payload.totalPages;
    },
    setUserArticles(state, action: PayloadAction<{ articles: any[]; totalPages: number }>) {
      state.userArticles = action.payload.articles;
      state.totalPages = action.payload.totalPages;
    },
    setError(state, action: PayloadAction<string>) {
      state.error = action.payload;
    },
    setCurrentPage(state, action: PayloadAction<number>) {
      state.currentPage = action.payload;
    },
  },
});

export const { setArticles, setUserArticles, setError, setCurrentPage } = articleSlice.actions;
export default articleSlice.reducer;

// Async actions to interact with the API
export const fetchArticles = (page: number, titleFilter : string, sourceFilter : string, dateFilter: string ) => async (dispatch: any, getState: any) => {
  const token =  getState().auth.token || localStorage.getItem('token');
  //console.log('Token ', token)
  console.log('ArticleSlice ', titleFilter);
  try {
    const { data } = await fetchArticlesService(page, token, titleFilter, sourceFilter, dateFilter);
    //console.log('User articles ', data);
    dispatch(setArticles({ articles: data.data, totalPages: data.last_page }));
    dispatch(setCurrentPage(page));
    dispatch(setError('')); // Reset error message
  } catch (error: any) {
    dispatch(setError(error.message));
  }
};

export const fetchUserArticles = (page: number) => async (dispatch: any, getState: any) => {
  //const token = getState().auth.token; // Get the token from Redux store (or you can use localStorage.getItem('token'))
  const token =  getState().auth.token || localStorage.getItem('token');
  try {

    const { data } = await fetchUserArticlesService(page, token);

    dispatch(setUserArticles({ articles: data.data, totalPages: data.last_page }));
    dispatch(setCurrentPage(page));
    dispatch(setError('')); // Reset error message
  } catch (error: any) {
    dispatch(setError(error.message));
  }
};
