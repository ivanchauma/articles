const API_URL = 'http://localhost:8000/api';
export default API_URL;